document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    console.log('Device is ready');
}

function saveContact() {
    var name = document.getElementById('name').value;
    var phone = document.getElementById('phone').value;

    var contact = navigator.contacts.create({
        "displayName": name
    });
    var phoneNumbers = [];
    phoneNumbers[0] = new ContactField('mobile', phone, true);
    contact.phoneNumbers = phoneNumbers;

    contact.save(addSuccess, addFailed);
}

function addSuccess() {
    alert("Contact Successfully added!");
    clearForm();
}

function addFailed(message) {
    alert("Add contact failed, reasons " + message);
}

function clearForm() {
    document.getElementById('name').value = '';
    document.getElementById('phone').value = '';
}
