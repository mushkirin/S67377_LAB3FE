var exec = require('cordova/exec');

module.exports = MupContactPlugin;