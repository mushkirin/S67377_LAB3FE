document.addEventListener('deviceready', function() {
    var deviceInfo = device;

    var deviceInfoList = document.getElementById('deviceInfoList');

    addDeviceInfoItem('UUID', deviceInfo.uuid  || 'N/A');
    addDeviceInfoItem('Model', deviceInfo.model || 'N/A');
    addDeviceInfoItem('Platform', deviceInfo.platform  || 'N/A');
    addDeviceInfoItem('Version', deviceInfo.version || 'N/A');
    addDeviceInfoItem('Manufacturer', deviceInfo.manufacturer || 'N/A');

    function addDeviceInfoItem(label, value) {
        var listItem = document.createElement('li');
        listItem.className = 'list-group-item';
        listItem.innerHTML = label + ': <span>' + value + '</span>';
        deviceInfoList.appendChild(listItem);
    }
});